




//EVENT HANDLER HTML element attribute
function block_appear(id) {
    var header_ids = ["ticketLabel", "diningLabel", "hotelLabel"];
    var form_ids = ["menu_ticket", "menu_dinings", "menu_hotel"];

    for (i=0; i<3; i++) {
        if (id == header_ids[i]) {
            document.getElementById(header_ids[i]).style.backgroundColor = "white";
            document.getElementById(form_ids[i]).style.display = "block";
        }
        else {
            document.getElementById(header_ids[i]).style.backgroundColor = "pink";
            document.getElementById(form_ids[i]).style.display = "none";
        }
    }

}

//EVENT HANDLER HTML element attribute
function add_item(button_id) {
    var n_guest = document.getElementById(button_id+'-qty').value;
    var img = document.getElementById(button_id+'-img');
    if (n_guest != '') {
        addRowTable(img.alt, n_guest);
        recal();
    }
}

function addRowTable(title, n_guest) {
    var tbody = document.getElementsByTagName('tbody')[0];
    
    var tr = document.createElement("tr");
    var td1 = document.createElement("td");
    td1.className = 'description';
    td1.innerHTML = title;
    tr.appendChild(td1);
    
    var td2 = document.createElement("td");
    td2.className = 'quantity';
    td2.innerHTML = n_guest;
    tr.appendChild(td2);

    tbody.appendChild(tr);
}


//EVENT HADNLER Javascript + html
var undo_handler = document.querySelector("#undo");
undo_handler.addEventListener("click", delete_row());



function recal() {
    var footer = document.getElementById('totalqty');
    var tr_array = document.getElementsByTagName("tr");
    var n_rows = tr_array.length, i, total = 0;

    for (i=1; i<n_rows-1; i++) {
        total += parseInt(tr_array[i].getElementsByClassName("quantity")[0].innerHTML);
    }
    footer.innerHTML = total;
}

function delete_row() {
    var tr_array = document.getElementsByTagName("tr");
    var n_rows = tr_array.length;
    var n_guest;

    var body = document.querySelector("tbody");
    if (!body.lastElementChild){
        alert("The table is already empty! Add an item.");
        element.removeEventListener("click", delete_row()); //cancels the onclick event
    }

    if (n_rows > 2) {
        n_guest = tr_array[tr_array.length-2].getElementsByClassName("quantity")[0].innerHTML;
        tr_array[tr_array.length-2].remove();
        recal();
    }
}

