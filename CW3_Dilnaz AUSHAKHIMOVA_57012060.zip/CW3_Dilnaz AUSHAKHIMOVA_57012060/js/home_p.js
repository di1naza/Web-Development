
// video source switch EVENT HANDLER Javascript
var videoOp = document.getElementById('video1');
videoOp.addEventListener("ended", SwitchVideo());

function SwitchVideo(){
    if(this.currentSrc == "https://personal.cs.cityu.edu.hk/~cs2204/video/Castle.mp4"){
        this.innerHTML = '<source src="https://personal.cs.cityu.edu.hk/~cs2204/video/Musical_Journey.mp4" type="video/mp4">';
    }
    else {
        this.innerHTML = '<source src="https://personal.cs.cityu.edu.hk/~cs2204/video/Castle.mp4" type="video/mp4">';
    }
    this.load();
}


